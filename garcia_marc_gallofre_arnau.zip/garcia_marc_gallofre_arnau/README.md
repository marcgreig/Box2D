# Box2D
Pinball Neon Pinball (https://www.classicgame.com/game/Neon+Pinball)

Marc Garcia & Arnau Gallofré

How to play:

Use Left and Right arrows to use flippers. Down arrow to launch the ball.

Debug:

F1 activate collisions. While collisions are visible you can drag the ball with the mouse.

GitHub: https://github.com/Trodek/Pinball_Game
